# Cambricon Guide

## limitations

### online

  MLU270 support batchsize: 1/4/16, corenumber: 1/4/16, quantization:int8， data type: float16/float32.

### offline

  MLU270 support batchsize: 1/4/16, corenumber: 1/4/16, quantization:int8， data type: float16/float32.

  MLU220 m.2 support batchsize: 1/4, corenumber: 1/4, quantization:int8/int16, data type: float16.

  MLU220 edge support batchsize: 1/4, corenumber: 4, quantization:int8/int16, data type: float16.
              support batchsize: 1, corenumber: 1, quantization:int8/int16, data type: float16.