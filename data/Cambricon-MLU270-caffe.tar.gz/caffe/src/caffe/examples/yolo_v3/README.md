# Cambricon Guide

## limitations

### supported networks
- yolov3
- yolov3-tiny

### online

  MLU270 support batchsize: 1/4/16, corenumber: 1/4/16, quantization:int8/int16, data type: float16/float32.

### offline

  MLU270 support batchsize: 1/4/16, corenumber: 1/4/16, quantization:int8/int16, data type: float16/float32.

  MLU220 m.2 support batchsize: 1/4/8, corenumber: 1/4, quantization:int8/int16, data type: float16/float32.

  MLU220 edge support batchsize: 1/4/8, corenumber: 1/4, quantization:int8/int16, data type: float16/float32.
